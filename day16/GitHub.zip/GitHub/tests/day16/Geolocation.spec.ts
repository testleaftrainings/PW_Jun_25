import test  from "@playwright/test"

test.use({
geolocation:{
latitude: 12.3106334,
longitude: 76.5532872
},
permissions:['geolocation'],

})


test("Geolocation Test", {tag:'@smoke'} ,async ({ page }) => {

await page.goto("https://www.google.com/maps")

await page.locator("#sVuEFc").click()

await page.waitForTimeout(10000)


})