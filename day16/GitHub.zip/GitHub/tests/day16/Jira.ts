import axios from "axios"


let endpoint="https://dilipkumaar2005.atlassian.net/rest/api/2/issue"
let mailID="dilipkumaar2005@gmail.com"
let apiToken="ATATT3xFfGF0HqYRs_LemtHCT5CPU6_W4zMDcjiX6aVtC2zjHcor8Fk275aAf5rJ5EnZJdJtmHsHmUkQJLZQXJArB8RLMvCw43m6lw8ctA3RS0rSPDz2y_O7gKRDnzpnAMCZzsEVPlLdabUoMICqrHy9Sn_EeVfLlz2oSbj9S_ddwvoTxWfbPuw=16ABDAF1"
let apiKey="PWJUN"

export async function createIssue(Summary:string, Description:string) {

    const issueData={

        "fields":{

            "project":{
                "key": apiKey
            },

            "summary": Summary,
            "description": Description,

            "issuetype":{
                "name":"Bug"
            },
    //         "assignee": {
    //   "name": "Dilip"
    // },

        }
    }
    


//api 


    const response = await axios.post(endpoint, issueData,{
        headers: {
            "Content-Type": "application/json",
        },
        auth:{
         
            username:mailID,
            password:apiToken
        }
    })


    console.log("Issue created successfully:", response.status);
   
}


createIssue("Issue is created from VS code", "This is a test issue created using the Jira API from VS Code.")