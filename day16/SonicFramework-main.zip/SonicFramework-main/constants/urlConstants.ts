export enum URLConstants {
    adminURL = "https://qeagle8-dev-ed.develop.my.salesforce.com/"
}