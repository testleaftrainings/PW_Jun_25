export enum URLConstants{
    baseURL="https://login.salesforce.com/?locale=in",
    instanceURL="https://qeagle8-dev-ed.develop.lightning.force.com"
}